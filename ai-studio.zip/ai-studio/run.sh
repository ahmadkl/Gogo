#!/bin/sh
cd "$(dirname "$0")/server"
[ -f .env ] && export $(grep -v '^#' .env | grep -v '^$' | xargs)
python3 -m uvicorn main:app --port 8000
