@echo off
cd /d "%~dp0server"
python -m uvicorn main:app --port 8000
pause
