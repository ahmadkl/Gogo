"""مزوّدو توليد المقاطع القصيرة. كل مزوّد يملك generate(prompt, seconds, out, image, seed)."""
import json, os, shutil, subprocess
from pathlib import Path

W = int(os.environ.get("VIDEO_WIDTH", 768))
H = int(os.environ.get("VIDEO_HEIGHT", 432))


class MockProvider:
    """يولّد مقاطع اختبار بـ ffmpeg لتجربة التمديد والدمج بدون GPU."""

    def generate(self, prompt, seconds, out, image=None, seed=0):
        n = int(seconds * 24)
        if image:
            vf = (f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
                  f"zoompan=z='min(zoom+0.0015,1.3)':d={n}:s={W}x{H}:fps=24")
            cmd = ["ffmpeg", "-y", "-i", str(image), "-vf", vf, "-t", str(seconds),
                   "-pix_fmt", "yuv420p", str(out)]
        else:
            cmd = ["ffmpeg", "-y", "-f", "lavfi", "-i",
                   f"testsrc2=size={W}x{H}:rate=24:duration={seconds}",
                   "-pix_fmt", "yuv420p", str(out)]
        subprocess.run(cmd, check=True, capture_output=True)


class GradioProvider:
    """يستدعي Hugging Face Space عبر gradio_client."""

    def __init__(self):
        from gradio_client import Client
        self.client = Client(os.environ["HF_SPACE"], hf_token=os.environ.get("HF_TOKEN") or None)
        self.api_name = os.environ.get("HF_API_NAME", "/predict")
        self.map = json.loads(os.environ.get(
            "HF_PARAM_MAP", '{"prompt":"prompt","image":"image","seconds":"duration","seed":"seed"}'))
        self.extra = json.loads(os.environ.get("HF_EXTRA_PARAMS", "{}"))

    def generate(self, prompt, seconds, out, image=None, seed=0):
        from gradio_client import handle_file
        kw = dict(self.extra)
        kw[self.map["prompt"]] = prompt
        if image and self.map.get("image"):
            kw[self.map["image"]] = handle_file(str(image))
        if self.map.get("seconds"):
            kw[self.map["seconds"]] = seconds
        if self.map.get("seed"):
            kw[self.map["seed"]] = seed
        res = self.client.predict(api_name=self.api_name, **kw)
        path = res[0] if isinstance(res, (list, tuple)) else res
        if isinstance(path, dict):
            path = path.get("video") or path.get("value") or path
        if isinstance(path, dict):
            path = path.get("path")
        shutil.copy(path, out)


def get_provider():
    name = os.environ.get("VIDEO_PROVIDER", "mock")
    if name == "gradio":
        return GradioProvider()
    if name == "local":
        return LocalVideoProvider()
    return MockProvider()


# ---------------- نماذج محلية (تعمل بدون إنترنت بعد تنزيلها مرة واحدة) ----------------
class LocalVideoProvider:
    """LTX-Video عبر diffusers: نص إلى فيديو وصورة إلى فيديو. يحتاج GPU (يُفضّل 12GB+)."""

    def __init__(self):
        import torch
        from diffusers import LTXImageToVideoPipeline, LTXPipeline
        dev = "cuda" if torch.cuda.is_available() else "cpu"
        mid = os.environ.get("LOCAL_VIDEO_MODEL", "Lightricks/LTX-Video")
        self.torch = torch
        self.i2v = LTXImageToVideoPipeline.from_pretrained(mid, torch_dtype=torch.bfloat16)
        self.t2v = LTXPipeline(**self.i2v.components)
        for p in (self.i2v,):
            if dev == "cuda":
                p.enable_model_cpu_offload()
            else:
                p.to("cpu")
        self.vw = int(os.environ.get("LOCAL_VIDEO_WIDTH", 704))
        self.vh = int(os.environ.get("LOCAL_VIDEO_HEIGHT", 480))
        self.steps = int(os.environ.get("LOCAL_VIDEO_STEPS", 30))

    def generate(self, prompt, seconds, out, image=None, seed=0):
        from diffusers.utils import export_to_video, load_image
        frames = max(9, int(seconds * 24) // 8 * 8 + 1)
        gen = self.torch.Generator().manual_seed(int(seed))
        kw = dict(prompt=prompt, negative_prompt="worst quality, blurry, distorted, jittery",
                  width=self.vw, height=self.vh, num_frames=frames,
                  num_inference_steps=self.steps, generator=gen)
        if image:
            img = load_image(str(image)).resize((self.vw, self.vh))
            res = self.i2v(image=img, **kw)
        else:
            res = self.t2v(**kw)
        export_to_video(res.frames[0], str(out), fps=24)


_img_pipe = None


def generate_image(prompt, width, height, seed, out):
    """sd-turbo محلي (سريع وخفيف). IMAGE_PROVIDER=mock لصورة اختبار."""
    if os.environ.get("IMAGE_PROVIDER", "local") == "mock":
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                        f"testsrc2=size={width}x{height}:rate=1", "-frames:v", "1", str(out)], check=True)
        return
    global _img_pipe
    import torch
    from diffusers import AutoPipelineForText2Image
    if _img_pipe is None:
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        _img_pipe = AutoPipelineForText2Image.from_pretrained(
            os.environ.get("LOCAL_IMAGE_MODEL", "stabilityai/sd-turbo"), torch_dtype=dtype)
        _img_pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    w, h = (min(width, 768) // 8 * 8), (min(height, 768) // 8 * 8)
    gen = torch.Generator().manual_seed(int(seed))
    img = _img_pipe(prompt=prompt, width=w, height=h, num_inference_steps=int(os.environ.get("LOCAL_IMAGE_STEPS", 4)),
                    guidance_scale=0.0, generator=gen).images[0]
    img.save(out)
